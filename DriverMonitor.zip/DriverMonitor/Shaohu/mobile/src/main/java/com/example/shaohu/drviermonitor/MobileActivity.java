package com.example.shaohu.drviermonitor;

import android.Manifest;
import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.test.mock.MockPackageManager;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.MqttException;

import java.io.UnsupportedEncodingException;

//public class MobileActivity extends AppCompatActivity implements SensorEventListener { // if access other sensor data
public class MobileActivity extends AppCompatActivity {
    private MqttAndroidClient client;
    private String TAG = "MainActivity";
    private PahoMqttClient pahoMqttClient;

    private EditText textMessage;
    private Button publishMessage;
    TextView sensorDataView;
    TextView delayedDataView;
    private TextView mHeartRateView;
    double latitude, longitude;
    double latitude1, longitude1;
    //float acceleration =0;
    String heartratevalue;
   // SensorManager sensorManager;
   // Sensor sensor;
    ToggleButton sendDataToggle;
    boolean sendDataEnabled = false;
    // GPSTracker class
    GPSTracker gps;
    private static final int REQUEST_CODE_PERMISSION = 1;
    String mPermission = Manifest.permission.ACCESS_FINE_LOCATION;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile);
        mHeartRateView = (TextView) findViewById(R.id.heart_rate_mobile);
        //sensorManager = (SensorManager) getSystemService(Service.SENSOR_SERVICE);
        //sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

       LocalBroadcastManager.getInstance(this).registerReceiver(
                new BroadcastReceiver() {
                    @Override
                    public void onReceive(Context context, Intent intent) {
                        //mHeartRateView.setText(String.format("%s", intent.getStringExtra(WearListCallListenerService.HEART_RATE)));
                        mHeartRateView.setText(intent.getStringExtra(WearListCallListenerService.HEART_RATE));
                    }
                }, new IntentFilter(WearListCallListenerService.BROADCAST_NAME)
        );

        try {
            if (ActivityCompat.checkSelfPermission(this, mPermission)
                    != android.content.pm.PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this, new String[]{mPermission},
                        REQUEST_CODE_PERMISSION);

                // If any permission above not allowed by user, this condition will
                //execute every time, else your else part will work
            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        sensorDataView = (TextView) findViewById(R.id.sensorDataView); // get a handle on the view element
        sensorDataView.setText("Starting Up...");
        delayedDataView = (TextView) findViewById(R.id.delayedDataView);
        delayedDataView.setText("longitude");

        sendDataToggle = (ToggleButton) findViewById(R.id.sendDataToggle);

        pahoMqttClient = new PahoMqttClient();

        textMessage = (EditText) findViewById(R.id.textMessage);
        publishMessage = (Button) findViewById(R.id.publishMessage);


        client = pahoMqttClient.getMqttClient(getApplicationContext(), Constants.MQTT_BROKER_URL, Constants.CLIENT_ID);

        publishMessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String msg = textMessage.getText().toString().trim();
                if (!msg.isEmpty()) {
                    try {
                        pahoMqttClient.publishMessage(client, msg, 1, Constants.PUBLISH_TOPIC);
                    } catch (MqttException e) {
                        e.printStackTrace();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                }
            }
        });


        sendDataToggle.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // The toggle is enabled
                    sendDataEnabled = true;
                } else {
                    // The toggle is disabled
                    sendDataEnabled = false;
                }
            }
        });

        Thread t1 = new Thread() {
            @Override
            public void run() {
                //super.run();
                while (!isInterrupted()) {
                    try {
                        Thread.sleep(1000);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                String msg;
                                // lightData++;
                                // delayedDataView.setText("Delayed: " + String.valueOf(lightData));

                                gps = new GPSTracker(MobileActivity.this);
                                latitude = gps.getLatitude();
                                longitude = gps.getLongitude();
                                Log.i("lat:",Double.toString(latitude));
                                Log.i("long:",Double.toString(longitude));
                                // check if GPS enabled
                                if (gps.canGetLocation()) {

                                    latitude1 = gps.getLatitude();
                                    longitude1 = gps.getLongitude();

                                    // \n is for new line
                                   // Toast.makeText(getApplicationContext(), "Your Location is - \nLat: "
                                     //       + latitude + "\nLong: " + longitude, Toast.LENGTH_LONG).show();
                                } else {
                                    // can't get location
                                    // GPS or Network is not enabled
                                    // Ask user to enable GPS/network in settings
                                    gps.showSettingsAlert();
                                }
                                sensorDataView.setText("Latitude: " + latitude);
                                delayedDataView.setText("Longitude: " + longitude);
                                if (sendDataEnabled) {

                                    heartratevalue =  mHeartRateView.getText().toString().trim();
                                    msg = String.valueOf(latitude) + "," + String.valueOf(longitude)+","+heartratevalue;
                                    try {
                                        pahoMqttClient.publishMessage(client, msg, 1, Constants.PUBLISH_TOPIC);
                                    } catch (MqttException e) {
                                        e.printStackTrace();
                                    } catch (UnsupportedEncodingException e) {
                                        e.printStackTrace();
                                    }
                                }
                            }
                        });

                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        t1.start();
        Intent intent1 = new Intent(MobileActivity.this, MqttMessageService.class);
        startService(intent1);
    }
    /*@Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if(sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
            delayedDataView.setText("acc: " + sensorEvent.values[1]);
            acceleration = sensorEvent.values[1];
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener(this);
        // disable sending of the data
        sendDataEnabled = false; // since we are not reading the sensor either when the app looses focus.
    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(this, sensor, SensorManager.SENSOR_DELAY_NORMAL);
        if(sendDataToggle.isChecked()){ // If the toggle button is ON
            sendDataEnabled = true;     // re-enable sending of  sensor data
        }
    }*/
}
