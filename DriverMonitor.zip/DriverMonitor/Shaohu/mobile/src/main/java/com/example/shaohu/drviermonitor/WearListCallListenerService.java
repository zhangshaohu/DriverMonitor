package com.example.shaohu.drviermonitor;

import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.WearableListenerService;


public class WearListCallListenerService extends WearableListenerService {
    public static final String LOG_KEY = "WEAR_SERVICE";
    public static final String HEART_RATE = "heart_rate";
    public static final String BROADCAST_NAME = WearListCallListenerService.class.getName() + "HearRateBroadcast";



    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(LOG_KEY, "Service onCreate() called!");
    }

    @Override
    public void onMessageReceived(MessageEvent messageEvent) {
        super.onMessageReceived(messageEvent);

        int heartRate = Integer.parseInt(messageEvent.getPath());
        Log.i(LOG_KEY, "Heart rate gathered from the watch!: " + heartRate);
        sendBroadcastMessage(Integer.toString(heartRate));
    }

    private void sendBroadcastMessage(String hearRate) {
        Intent intent = new Intent(BROADCAST_NAME);
        intent.putExtra(HEART_RATE, hearRate);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
}
