package com.example.shaohu.drviermonitor;

/**
 * Created by brijesh on 20/4/17.
 */

public class Constants {

    public static final String MQTT_BROKER_URL = "tcp://35.196.98.6:1883";

    public static final String PUBLISH_TOPIC = "topic/watch";

    public static final String CLIENT_ID = "androidkt";
}

